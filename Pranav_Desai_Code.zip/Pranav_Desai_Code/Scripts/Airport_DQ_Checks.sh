spark-shell
 val ss